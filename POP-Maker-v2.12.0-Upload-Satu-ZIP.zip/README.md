# POP Maker v2.12.0 — Source Android

Paket ini digunakan dengan **build dari satu ZIP**.
Unggah **POP-Maker-v2.12.0-Upload-Satu-ZIP.zip** langsung sebagai satu file ke root GitHub repository.
**Jangan ekstrak** ketika mengunggah.

Sebelum unggahan ZIP pertama, pasang sekali workflow
`.github/workflows/build-from-zip.yml` **di repository GitHub** memakai file
`build-pop-maker-from-zip.yml` yang disediakan terpisah.
GitHub tidak menjalankan workflow yang hanya tersimpan di dalam ZIP.

Sesudah workflow dipasang: upload ZIP > Commit > Actions >
Build POP Maker Debug APK dari ZIP > Artifacts > POP-Maker-Debug-APK.

Aplikasi: POP Maker v2.12.0 / Android 10+ / Gradle 8.9 / Java 17.
