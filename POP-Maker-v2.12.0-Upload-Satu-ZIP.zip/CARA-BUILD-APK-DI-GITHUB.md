# Cukup Upload Satu ZIP

Repo GitHub harus sudah memiliki `.github/workflows/build-from-zip.yml` (setup sekali).
Setelah itu upload `POP-Maker-v2.12.0-Upload-Satu-ZIP.zip` tanpa ekstrak ke root repository.
Commit, lalu buka Actions > Build POP Maker Debug APK dari ZIP > Artifacts.
GitHub menyimpan ZIP apa adanya; file workflow wajib tersedia di luar ZIP.
