#!/usr/bin/env python3
"""Sanity-check the inline offline editor without third-party Python packages."""
from html.parser import HTMLParser
from pathlib import Path
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]
HTML = ROOT / "app/src/main/assets/index.html"

class EditorParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.scripts = []
        self.in_script = False
        self.ids = set()
    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if "id" in attrs:
            assert attrs["id"] not in self.ids, f"Duplicate id: {attrs['id']}"
            self.ids.add(attrs["id"])
        if tag == "script" and "src" not in attrs:
            self.in_script = True
            self.scripts.append("")
    def handle_endtag(self, tag):
        if tag == "script": self.in_script = False
    def handle_data(self, data):
        if self.in_script: self.scripts[-1] += data

parser = EditorParser()
parser.feed(HTML.read_text(encoding="utf-8"))
required = {"posterCanvas", "undoEdit", "redoEdit", "importCsv", "exportCsv", "sampleCsv", "csvFile", "printPoster", "saveProject", "templateGallery", "periodMode", "periodMonth", "periodRange", "periodStart", "periodEnd", "layerOverlay", "layerX", "layerY", "layerW", "layerH", "activeLayerInfo", "directEditStatus", "periodColor", "activeTextSize", "activeTextX", "activeTextY", "textEffectsList", "objectPalette", "paletteValue", "paletteColor", "paletteFont", "paletteStyle", "paletteImageWidth", "paletteImageHeight", "paletteQuickShape", "paletteAdvancedContent", "paletteShelfPeriod", "minimizePalette"}
assert required.issubset(parser.ids), f"Missing UI elements: {required - parser.ids}"
assert len(parser.scripts) == 1, "Expected one self-contained inline JavaScript editor"
assert 'product-shape-controls' in HTML.read_text(encoding='utf-8'), "Per-product Card/Shapes panel missing"
assert 'function productShape(' in HTML.read_text(encoding='utf-8'), "Shape normalization missing"
assert 'shape:productShape(item.shape)' in HTML.read_text(encoding='utf-8'), "Shape JSON compatibility missing"
assert 'data-tab="style"' not in HTML.read_text(encoding="utf-8"), "Tab Tampilan must be removed"
assert 'data-tab="project"' not in HTML.read_text(encoding="utf-8"), "Proyek tab must be removed"
assert 'id="productProjectTools"' in HTML.read_text(encoding="utf-8"), "Project tools must be in product list"
assert '.workspace > .stage{position:relative!important' in HTML.read_text(encoding="utf-8"), "Preview must follow page scroll"
assert "function syncPalette()" in HTML.read_text(encoding="utf-8"), "Context layer palette missing"
assert "function fontSpec(" in HTML.read_text(encoding="utf-8"), "Per-layer font style rendering missing"
assert "#paletteQuickShape,#paletteObjectControls,#paletteShelfControls,#paletteMore{display:none!important}" in HTML.read_text(encoding="utf-8"), "Legacy palette controls must be hidden"
assert "toggleSelection" not in parser.ids, "The selection mode button must not be present"
assert "layerButtons" not in parser.ids, "Separate layer picking controls must not be present"
assert "gridOverlay" in parser.ids, "Invisible grid compatibility node missing"
assert "periodColor:'#171b25'" in HTML.read_text(encoding="utf-8"), "Missing period color in defaults"
assert 'ctx.fillStyle=state.settings.periodColor' in HTML.read_text(encoding="utf-8"), "Missing Selftaker period color rendering"
assert "st.periodColor||'#171b25'" in HTML.read_text(encoding="utf-8"), "Missing A4 period color rendering"
assert "function directLayerAtPoint" in HTML.read_text(encoding="utf-8"), "Missing direct canvas hit testing"
assert "directCanvas.addEventListener('pointerdown'" in HTML.read_text(encoding="utf-8"), "Missing direct canvas gestures"
assert '.layer-hit.is-selected::before' in HTML.read_text(encoding="utf-8"), "No-selection styling missing"
assert '{id:"label"' not in HTML.read_text(encoding="utf-8"), "The AQUA selection example must not be a background"
assert HTML.read_text(encoding="utf-8").count('{id:"') == 6, "Expected six promo templates"
assert 'function withTextWarp(' in HTML.read_text(encoding="utf-8"), "Missing canvas text warp"
assert 'function normalizeTextEffects(' in HTML.read_text(encoding="utf-8"), "Missing legacy migration"
assert 'selection-resize-x' in HTML.read_text(encoding="utf-8") and 'selection-resize-y' in HTML.read_text(encoding="utf-8"), "Missing separate width/height handles"
with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", suffix=".js") as script:
    script.write(parser.scripts[0])
    script.flush()
    subprocess.run(["node", "--check", script.name], check=True)
print(f"OK: JS syntax and {len(parser.ids)} unique editor controls")
