## v2.12.0 — Pulihkan harga promo yang hilang di poster
- Tambah tombol **🎯 Munculkan harga promo di poster** di dalam **Daftar Produk → Data produk dan harga** untuk tiap produk.
- Tombol memulihkan posisi layer harga, ukuran huruf, skala horizontal/vertikal, dan warna promo merah jika pengaturan sebelumnya menyebabkan harga hilang atau berada di luar kanvas.
- Nilai nominal promo dan normal, foto, teks nama/deskripsi, shapes, periode dan background tidak dihapus.
- Preview di-reset ke zoom 100% untuk mempermudah menemukan harga setelah pemulihan; harga bisa digeser kembali pada kanvas.
- Layer promo pada POP A4 tetap memakai posisi bersama sehingga pengaturan layout multi-produk tetap konsisten. Selftaker tetap memiliki 9 slot.
- Pengujian browser simulasi HP/desktop dan skenario harga tidak terlihat, serta pemeriksaan sintaks JavaScript lulus; APK fisik belum diuji.

## v2.11.0 — Card / Shapes per produk dipulihkan
- Memunculkan kembali Card / Shapes tepat di setiap kartu Daftar Produk (Lihat/Sembunyikan).
- Memberi masing-masing produk bentuk, warna isi, warna garis, lengkung sudut, ketebalan garis dan reset sendiri.
- Mode bawaan menjaga tampilan versi 2.10.0 tetap sama, termasuk tanpa kartu di POP A4 bebas.
- Render POP A4, kartu grid dan 9 slot Selftaker mendukung pengaturan per produk.
- Impor proyek lama dan simpan JSON mempertahankan kompatibilitas dan pengaturan shape.
- Pengujian browser desktop/mobile lulus; APK fisik belum diuji.

## v2.10.0 — Zoom Live Preview di HP
- Kontrol zoom `−`, slider 25–400%, `+`, serta tombol `Pas` kini tersedia di bagian atas Live Preview HP.
- Mendukung cubit dua jari (pinch-to-zoom) pada poster di HP dan drag area kosong untuk menggeser kanvas yang diperbesar.
- Pembagian layar HP 50:50 dipertahankan: preview di atas, pengaturan/Daftar Produk di bawah dengan scroll terpisah.
- Zoom hanya untuk tampilan: desain PNG/JPG dan ukuran cetak tetap seperti sebelumnya.
- Desktop tetap memiliki preview tetap di kanan dan scroll mandiri menu kiri, tanpa perubahan perilaku zoom desktop.
- Pengujian Chromium/Playwright: lebar 390 px, 768 px, 1280 px; zoom 250%, pinch, pan, reset dan split panel; pemeriksaan sintaks JavaScript.
- APK belum dikompilasi atau diuji di HP fisik.

## v2.9.0 — Live Preview tetap di layar, editor bergulir terpisah
- Layar HP dibagi 50:50: Live Preview atas dan panel editing bawah.
- Desktop: Live Preview kanan stabil, hanya menu editing kiri yang bergulir.
- Kontrol download PNG, JPG dan Cetak tetap tersedia pada preview.
- Mempertahankan edit langsung, zoom, bentuk foto fleksibel, dan seluruh template.

## v2.8.0 — Bentuk Foto Fleksibel
- Lebar dan tinggi tiap foto bisa diatur independen (slider 10–400%, input presisi 1–1000%).
- Preset bentuk cepat: Asli, Gepeng, Lebar, Panjang.
- Kotak seleksi foto mendukung tarik sisi kanan untuk lebar, sisi bawah untuk tinggi, dan sudut untuk keduanya.
- Proporsi foto bisa dikunci melalui checkbox. Ukuran disimpan pada proyek dan berlaku di POP A4 maupun Selftaker.
- Semua pengaturan tetap di Daftar Produk → Pengaturan Foto, dengan Lihat/Sembunyikan.

## 2.7.0 — 2026-11-20

- Hapus tab Daftar Objek; gabungkan pemilih objek dan palet teks/foto/outline ke Daftar Produk.
- Tambahkan tautan Edit layer, font, warna & outline pada setiap kartu produk.
- Tambahkan tombol Lihat / Sembunyikan pada kelompok menu utama dan setiap produk, serta rincian data/harga, pengaturan gambar, edit objek, outline, dan alat proyek.
- Pertahankan selisih mode A4 dan Selftaker, template standar dan impor, export, undo/redo, zoom-pan, dan scroll normal halaman.
- Uji browser desktop/mobile, empat slot produk, outline, Selftaker slot 9 dan unduh JSON.

## 2.6.0 — 2026-11-20

- Gabungkan seluruh menu Proyek ke dalam Daftar Produk (bagian expand/collapse).
- Hapus tab Proyek; pertahankan tab Konten dan Daftar Objek.
- Hilangkan mode sticky pada Live Preview desktop: seluruh preview mengikuti scroll halaman.
- Nonaktifkan preview melayang otomatis di HP agar tidak mengunci atau menutupi poster.
- Pertahankan zoom, pan, dan edit objek di dalam area preview.
- Tidak mengubah struktur data proyek / format ekspor.

## v2.5.0 — Live Preview bisa digeser saat zoom (20 November 2026)

- Geser area kosong poster menggunakan mouse atau sentuhan untuk menjelajahi bagian kanvas pada zoom lebih dari 100%.
- Tahan **Spasi + drag** untuk menggeser kanvas termasuk ketika kursor berada di atas foto atau teks. Tombol tengah mouse + drag juga didukung.
- Shift + scroll menggeser kanvas ke samping; Ctrl + scroll tetap memperbesar/memperkecil.
- Mengedit dan memindahkan objek dengan drag biasa tidak berubah. Seleksi dan pegangan resize tetap bekerja.
- Pan hanya mengubah tampilan editor, bukan tata letak poster ataupun hasil ekspor PNG/JPG.

## v2.4.0 — Daftar Objek tanpa floating palette + Impor Template (20 November 2026)

- Hapus perilaku palet editing melayang; pindahkan pengaturan teks dan outline ke **tab Daftar Objek** di panel Pengaturan Desain.
- Tab memiliki pemilih produk/slot dan 6 jenis objek: Foto, Nama, Deskripsi, Harga Coret, Harga Promo, dan Tanggal. Ketuk objek pada poster atau pilih melalui daftar untuk mengedit.
- Pengaturan teks yang ditampilkan: Edit Teks, Warna Font, Jenis Font, Gaya Font, dan Outline (mode, warna, ketebalan). Foto bisa diganti pada tab Daftar Objek. Kotak seleksi hanya pada layer terpilih.
- Tombol **＋ Impor Template** menerima gambar JPG, PNG, WebP dari galeri atau komputer. File impor muncul di bagian **Template Saya** terpisah; keenam template bawaan Alfamidi tetap tersedia dan tidak bisa terhapus oleh fitur ini.
- Template impor disimpan terpisah dalam IndexedDB jika penyimpanan browser tersedia; bila tidak, aplikasi tetap mengizinkan impor sementara dan menampilkan notifikasi. JSON proyek juga menyimpan background yang terpilih.
- Cegah perpindahan tab saat pointer sedang menyeret objek agar posisi kanvas di HP tetap stabil.
- Periode POP A4 tetap satu, Selftaker tetap sembilan; kontrol zoom desktop dan hasil ekspor tetap dipertahankan.
- Uji sintaks, uji browser desktop/mobile untuk palet inline, font/outline, pemilihan layer, impor template, dan enam template bawaan. APK belum dijalankan pada perangkat Android fisik.

## v2.3.0 — Outline per layer & zoom live preview desktop (20 November 2026)

- Tambahkan panel Outline Teks langsung di Palet Objek yang terbuka saat pengguna menekan nama, deskripsi, harga normal, harga promo, atau tanggal.
- Pilihan: tanpa outline, otomatis mengikuti warna kartu, atau outline warna custom; warna dan ketebalan 0,5–40 px bisa diatur langsung.
- Outline disimpan per objek produk (berdasarkan ID produk), satu tanggal A4, atau per slot tanggal Selftaker 1–9. Perubahan hanya mengenai objek terpilih.
- Outline dipakai dalam gambar kanvas, ekspor PNG/JPG/cetak, autosave, Undo/Redo, dan file proyek JSON. Proyek versi lama tetap didukung.
- Tambahkan zoom editor desktop 25–400% melalui slider, tombol − / + / Pas 100%, dan Ctrl/Alt + roda mouse di area preview.
- Zoom hanya mengubah ukuran tampilan preview, tidak mengubah ukuran output A4 1131×1600, posisi/ukuran objek, ataupun resolusi cetak; selection box dan drag layer tetap bekerja saat diperbesar.
- Zoom desktop diuji ke 250%, memilih dan menyeret nama produk serta reset zoom. Outline diuji pada mobile POP A4 dan Selftaker. APK fisik belum diuji.

## v2.2.0 — Palet teks ringkas

- Palet objek teks hanya menampilkan edit tulisan, warna font, jenis font, dan gaya font (bawaan/normal/tebal/miring/tebal-miring).
- Pengaturan teks berlaku langsung pada hasil poster, termasuk POP A4 dan 9 slot Selftaker.
- Kontrol lama (ukuran, lebar, tinggi, posisi, layout dan efek) tidak lagi ditampilkan pada palet, sedangkan sentuh/geser dan resize langsung di poster tetap tersedia.

## v2.1.0 — Edit semua gaya dari Palet Objek (20 November 2026)

- Hapus tab Tampilan dari Pengaturan Desain. Tab Konten dan Proyek tetap tersedia.
- Pindahkan pengaturan posisi/ukuran layer ke palet kontekstual yang muncul saat mengetuk foto, teks, harga, atau periode pada poster.
- Tambah kontrol langsung untuk isi teks, warna masing-masing teks, font, ukuran/gepeng/panjang teks, foto produk, serta pengaturan layout dan efek lanjut di palet.
- Sediakan pengubah warna nama, deskripsi, dan harga normal selain harga promo dan periode.
- Perkecil palet pada HP agar objek terpilih terlihat serta tambahkan ringkas/buka dan tutup palet.
- Ketuk slot Selftaker untuk membuka palet terkait; 9 tanggal tetap independen.
- Hilangkan kontrol tampilan permanen dari panel editor, pertahankan kompatibilitas file proyek lama dan ekspor bersih.
- Perbarui pemeriksaan kontrol unik dan pengujian browser mobile/desktop.

## v2.0.0 — Tipografi bebas: ukuran, lebar, dan tinggi (20 November 2026)

- Pengaturan baru untuk lima jenis tulisan: nama, deskripsi, harga normal, harga promo, dan tanggal/periode. Masing-masing memiliki ukuran huruf, skala lebar dan skala tinggi independen, tanpa atribut `max` pada input.
- Rendering kanvas menggunakan `translate/scale` untuk menggepengkan atau memanjangkan teks pada dua sumbu, termasuk outline dan harga coret.
- Menghilangkan pengecilan otomatis teks apabila efek kustom dipakai; deskripsi dengan efek kustom menjadi satu baris yang bisa dibentuk bebas.
- Popup seleksi tetap hanya mengelilingi objek yang disentuh; pegangan ↔/↕/↘ mengubah bentuk teks, tanpa mengubah foto atau bingkai kartu.
- Tipografi Selftaker mendukung efek serupa untuk semua sembilan slot; nilai mode tersimpan terpisah.
- Migrasi project JSON lama secara aman ke parameter 100%, serta dukungan autosave, Undo/Redo, PNG/JPG, dan cetak.

## v1.9.0 — Warna tanggal dapat diubah

- Tambah pengaturan **Warna tanggal** pada panel **Pengaturan desain → Warna & elemen**.
- Pilihan warna langsung mengubah tulisan tanggal POP A4 (satu periode) dan tulisan semua sembilan periode Selftaker.
- Pilihan warna ikut tersimpan pada proyek, Undo/Redo, dan hasil ekspor PNG/JPG atau cetak.
- Font tanggal POP A4 sekarang mengikuti opsi **Font periode promo**.
- Tetap kompatibel dengan proyek versi sebelumnya; tanggal lama tetap memiliki warna default bila belum memilih warna sendiri.

## v1.8.0 — Seleksi tipis mengikuti objek (20 November 2026)

- Tampilkan kotak seleksi hanya pada layer yang disentuh, mengikuti batas visual foto/teks.
- Kotak transparan di atas seluruh grid tetap dinonaktifkan: hit-test langsung pada canvas v1.7.0 dipertahankan.
- Tambah resize dari pegangan sudut objek, pemilihan satu objek, tap-ulang untuk melepas, dan tap area kosong untuk melepas.
- Ekspor PNG/JPG/cetak tetap bersih (lapisan seleksi tidak digambar ke canvas).
- Penyimpanan posisi/ukuran dan sinkronisasi antarproduk tetap aktif.
- Tes sintaks dan simulasi browser mobile berhasil; belum build APK fisik.

## v1.7.0 — Sentuh dan geser langsung di canvas (20 November 2026)

- Hilangkan elemen transparan yang sebelumnya menangkap pointer di atas kanvas; kini gesture langsung pada `posterCanvas` sehingga Android WebView tidak perlu meneruskan event ke elemen overlay.
- Hit-testing berdasarkan batas visual tiap objek dengan toleransi jari, mempertimbangkan lapisan teks di depan gambar.
- Tampilan status objek aktif setelah satu ketukan tanpa pilihan mode dan tanpa bingkai seleksi.
- Drag memakai Pointer Events dan `setPointerCapture` pada canvas; gerakan menyimpan koordinat X/Y, refresh preview dan autosave.
- Fitur satu periode A4/sembilan periode Selftaker v1.6.0 dipertahankan.
- Lulus pemeriksaan sintaks dan pengujian gesture browser mobile; APK belum dikompilasi/diuji pada perangkat fisik.

## v1.6.0 — Satu tanggal A4 dan sembilan periode Selftaker (20 November 2026)

- Memisahkan pengaturan periode menurut jenis poster.
- POP A4 sekarang hanya menggambar satu teks periode pada kanvas global; tidak lagi mengulang periode untuk setiap produk pada layout banyak kolom.
- Satu tanggal A4 dapat disentuh langsung dan digeser bebas tanpa kotak seleksi.
- Selftaker menyimpan 9 periode independen sesuai sembilan slot grid 3×3. Bisa dikosongkan per slot atau disamakan semua dari slot 1.
- Perbaikan persistensi, serialisasi dan migrasi proyek lama, termasuk draft tiap mode, Undo/Redo, dan ekspor gambar.
- Lulus pemeriksaan statis dan tes browser mobile; APK belum dibangun pada perangkat ini.

## v1.5.0 — Langsung sentuh dan geser tanpa seleksi (20 November 2026)

- Hapus tombol **Pilih Layer** dan semua tombol toolbar pemilihan layer.
- Hilangkan overlay pemilihan grid, garis putus-putus, bulatan resize, serta bingkai dan label seleksi layer pada pratinjau.
- Pertahankan area sentuh transparan tepat di atas objek agar foto/nama/deskripsi/harga/tanggal dapat digeser langsung dengan mouse atau sentuhan.
- Untuk resize, tersedia input Lebar dan Tinggi pada **Pengaturan objek** tanpa pegangan di kanvas.
- Perbaiki prioritas sentuh nama produk yang berdekatan dengan teks periode.
- Aktifkan mode freeform pada A4 dan nonaktifkan kotak kartu lama pada proyek tersimpan saat migrasi pertama.
- Perbarui nomor versi Android dan nama artifact build; lolos pengujian browser desktop/mobile dan gesture sentuhan HP.

## v1.4.0 — Per-layer touch selection

- Hilangkan bingkai grid besar pada A4.
- Ketuk tiap objek untuk seleksi individual (tanpa mengaktifkan bingkai seluruh grid).
- Kotak seleksi dan resize hanya untuk satu objek aktif.
- Pemindahan dan resize konsisten untuk semua sel di layout multi-kolom.
- Ketuk lagi atau area kosong untuk melepas.

# Changelog

## v1.3.0 — Seleksi opsional dan galeri template yang benar

- Menghapus contoh AQUA dari template background (dari 7 menjadi 6).
- Tombol on/off mode seleksi di toolbar preview; default off.
- Tap layer untuk memilih, drag untuk memindahkan, tap lagi untuk melepas.
- Tap area kosong poster untuk menutup seleksi.
- Garis kotak, border grid, dan titik handle otomatis tidak terlihat ketika mode seleksi mati.
- Export/cetak tetap tidak menyertakan bingkai edit.

# Changelog

## v1.2.0 — 2026-11-20

- Tambahkan tujuh template background terkurasi dari gambar pengguna.
- Perkenalkan editor A4 berbasis layer independen: foto, nama, deskripsi, harga normal, harga promo, dan tanggal.
- Tambahkan drag and drop pada layer dan kontrol numerik X, Y, lebar, dan tinggi.
- Samakan posisi tiap layer otomatis di seluruh kolom dan baris yang mengikuti sel pertama.
- Tambahkan grid 1 × 1 dan default proyek 1 produk.
- Tambahkan pilihan promo Jumat–Minggu, Senin–Minggu, setengah bulan, dan custom.
- Pastikan pola tanggal memperhitungkan panjang bulan dan tahun kabisat.
- Pisahkan petunjuk dan kontrol layout lama saat menggunakan freeform agar tidak membingungkan.
- Verifikasi mode browser desktop/mobile dan automasi drag, Undo/Redo, serta tanggal.
- Tidak ada APK yang dikompilasi di lingkungan ini; workflow GitHub tetap tersedia.


## v1.1.0 — 2026-11-20

- Tambah Undo / Redo hingga 35 checkpoint per sesi, termasuk perubahan input, layout, foto, dan proyek.
- Tambah impor / ekspor dan contoh CSV massal (produk, deskripsi, harga normal/promo).
- Perbaiki Android file picker agar file `.json` dan `.csv` dapat dibuka.
- Hubungkan unduhan PNG/JPG/JSON/CSV ke Android `NativeBridge` melalui chunk Base64; file disimpan dengan MediaStore.
- Tambah pencegahan transfer paralel dan pemeriksaan hasil penerimaan transfer Android.
- Hubungkan tombol Cetak ke Android PrintManager dan sembunyikan Undo/Redo dari halaman cetak.
- Perbarui workflow GitHub Actions, nama artifact, dan versi Android menjadi `1.1.0`.
- Tambah pemeriksaan JavaScript/editor di `tools/check_editor.py` dan sampel CSV.

### Validasi

- Lolos pemeriksaan `node --check` atas editor JavaScript inline.
- Lolos 14 smoke test Chromium: startup, Undo/Redo, parser/serialisasi CSV, perubahan daftar produk, jembatan download, cetak, dan tidak ada runtime error JavaScript.
- Layout di viewport 390px dan 1280px tidak memiliki overflow horizontal.
- Mode print menyembunyikan tombol Undo/Redo dan overlay editor.
- **Belum diuji membangun APK dengan Android SDK atau menjalankan APK pada perangkat Android fisik**.
